# Notebook AI

A source-grounded AI notebook for Android, in the spirit of Google NotebookLM: add your own sources, chat with them (answers cite the exact passages), and generate study material. It is an independent app, not affiliated with Google.

## What it does
- **Sources**: PDF (with page numbers), Word (.docx), TXT/MD/CSV/HTML files, pasted text, web links. Toggle sources on or off.
- **Cited chat**: answers use only your sources; tap a numbered chip to see the passage.
- **Studio**: summary, briefing doc, study guide, FAQ, timeline, mind map, flashcards, quiz. Results are saved in Notes.
- **Notes**: save chat answers, write your own, share or copy.
- **Private**: notebooks are stored on the device. Your OpenAI key stays on the device; sources are sent to the API only when you chat or generate.

Not included yet: audio overviews, video overviews, YouTube import, OCR for scanned PDFs, sync across devices.

## Get the APK (easiest: GitHub)
1. Create a new GitHub repository and upload this whole folder.
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow**.
3. When it finishes (about 5 minutes), download the `notebook-ai-apk` artifact, unzip it and install `app-debug.apk` on your phone (allow installs from your browser or file manager).

## Or build locally
Needs Node 20+, JDK 21 and Android Studio (Android SDK).
```
npm install
npm test
npm run sync          # copies PDF/Word libraries and syncs Android
npx cap add android   # first time only, run before sync
cd android && ./gradlew assembleDebug
```
The APK is at `android/app/build/outputs/apk/debug/app-debug.apk`. You can also run `npx cap open android` and build from Android Studio.

## First use
Open ⚙️ Settings, paste your OpenAI API key, and pick a model (default `gpt-4o-mini`; any chat model your key can use works).

## Try it in a desktop browser
`npm install && npm run prepare:www`, then serve the `www` folder (for example `npx serve www`) and open it.
