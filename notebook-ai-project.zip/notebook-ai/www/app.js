import {
  uid, escapeHtml, buildChunks, searchChunks, coverageChunks, formatPassages,
  SYSTEM_CHAT, SYSTEM_STUDIO, STUDIO, parseJSONLoose, renderMarkdown, htmlToText, titleFromHtml,
} from './core.js';

/* ---------- storage ---------- */
const DB_NAME = 'notebook-ai', STORE = 'notebooks';
let dbp;
function db() {
  if (!dbp) dbp = new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE, { keyPath: 'id' });
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  return dbp;
}
async function tx(mode, fn) {
  const d = await db();
  return new Promise((res, rej) => {
    const t = d.transaction(STORE, mode);
    const out = fn(t.objectStore(STORE));
    t.oncomplete = () => res(out && 'result' in out ? out.result : undefined);
    t.onerror = () => rej(t.error);
  });
}
const allNotebooks = async () => (await tx('readonly', s => s.getAll())).sort((a, b) => b.updated - a.updated);
const putNotebook = nb => { nb.updated = Date.now(); return tx('readwrite', s => s.put(nb)); };
const removeNotebook = id => tx('readwrite', s => s.delete(id));

const SETTINGS_KEY = 'notebook-ai-settings';
const settings = () => ({ apiKey: '', model: 'gpt-4o-mini', baseUrl: 'https://api.openai.com/v1', ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') });
const saveSettings = s => localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));

/* ---------- ui helpers ---------- */
const $ = sel => document.querySelector(sel);
const app = $('#app');
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add('hidden'), 2600);
}
function openSheet(html) { const m = $('#modal'); m.innerHTML = '<div class="sheet">' + html + '</div>'; m.classList.remove('hidden'); }
function closeSheet() { $('#modal').classList.add('hidden'); $('#modal').innerHTML = ''; }
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeSheet(); });

async function shareText(title, text) {
  try { if (navigator.share) { await navigator.share({ title, text }); return; } } catch (e) { if (e.name === 'AbortError') return; }
  try { await navigator.clipboard.writeText(text); toast('Copied to clipboard'); }
  catch { toast('Could not share or copy'); }
}

/* ---------- OpenAI ---------- */
function nativeHttp() {
  const C = window.Capacitor;
  return C && C.Plugins && C.Plugins.CapacitorHttp && (!C.isNativePlatform || C.isNativePlatform()) ? C.Plugins.CapacitorHttp : null;
}
function apiError(status, j) {
  let msg = 'Request failed (' + status + ')';
  if (j && j.error && j.error.message) msg = j.error.message;
  if (status === 401) msg = 'Invalid API key. Check it in Settings.';
  else if (status === 429) msg = 'Rate limit reached or no credit left on your OpenAI account. ' + msg;
  const e = new Error(msg); e.apiStatus = status; return e;
}
function unreachable(url, e) {
  let host = url; try { host = new URL(url).host; } catch { /* keep */ }
  return 'Could not reach ' + host + ' (' + ((e && e.message) || 'no details') + '). Check your internet, and turn off any VPN, ad blocker or Private DNS, then try again.';
}
async function testConnection(key, baseUrl) {
  if (!key) return 'Enter your API key first.';
  if (!/^[\x21-\x7e]+$/.test(key)) return '⚠️ The key has spaces or unusual characters. Copy it again.';
  const url = baseUrl.replace(/\/+$/, '') + '/models';
  const headers = { Authorization: 'Bearer ' + key };
  const verdict = status => status === 200 ? '✅ Connected. Your key works.' : status === 401 ? '❌ Reached OpenAI, but the key was rejected.' : '⚠️ Reached the server, but it answered ' + status + '.';
  try { const r = await fetch(url, { headers }); return verdict(r.status); }
  catch (e) {
    const nat = nativeHttp();
    if (nat) { try { const r = await nat.get({ url, headers }); return verdict(r.status) + ' (via native)'; } catch (e2) { return '❌ ' + unreachable(url, e2); } }
    return '❌ ' + unreachable(url, e);
  }
}
async function callAI(messages, { json = false, onToken } = {}) {
  const s = settings();
  if (!s.apiKey) throw new Error('Add your OpenAI API key in Settings first.');
  const body = { model: s.model, messages };
  if (json) body.response_format = { type: 'json_object' };
  if (onToken) body.stream = true;
  if (!/^[\x21-\x7e]+$/.test(s.apiKey)) throw new Error('The API key has spaces or unusual characters. Copy it again and paste it in Settings.');
  const url = s.baseUrl.replace(/\/+$/, '') + '/chat/completions';
  const headers = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.apiKey };
  let res;
  try {
    res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body) });
  } catch (e) {
    // The WebView could not make the request. On Android, retry through the native HTTP layer (no streaming).
    const nat = nativeHttp();
    if (!nat) throw new Error(unreachable(url, e));
    let r;
    try { r = await nat.post({ url, headers, data: body, responseType: 'json' }); }
    catch (e2) { throw new Error(unreachable(url, e2)); }
    if (r.status >= 400) throw apiError(r.status, r.data);
    const text = r.data.choices[0].message.content || '';
    if (onToken) onToken(text);
    return text;
  }
  if (!res.ok) { let j = null; try { j = await res.json(); } catch { /* ignore */ } throw apiError(res.status, j); }
  if (!onToken) { const j = await res.json(); return j.choices[0].message.content || ''; }
  const reader = res.body.getReader(), dec = new TextDecoder();
  let buf = '', full = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split('\n'); buf = lines.pop();
    for (const ln of lines) {
      const l = ln.trim();
      if (!l.startsWith('data:')) continue;
      const d = l.slice(5).trim();
      if (d === '[DONE]') continue;
      try { const tok = JSON.parse(d).choices[0].delta.content; if (tok) { full += tok; onToken(full); } } catch { /* partial */ }
    }
  }
  return full;
}

/* ---------- importers ---------- */
function loadScript(src) {
  return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('Could not load ' + src)); document.head.appendChild(s); });
}
async function extractPdf(file) {
  const pdfjs = await import('./lib/pdf.min.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = new URL('./lib/pdf.worker.min.mjs', import.meta.url).href;
  const doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  const pages = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const tc = await (await doc.getPage(i)).getTextContent();
    let t = '';
    for (const it of tc.items) t += it.str + (it.hasEOL ? '\n' : ' ');
    pages.push({ page: i, text: t });
  }
  return { text: pages.map(p => p.text).join('\n\n'), pages };
}
async function extractDocx(file) {
  if (!window.mammoth) await loadScript('./lib/mammoth.browser.min.js');
  const r = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
  return { text: r.value, pages: null };
}
async function extractFile(file) {
  const n = file.name.toLowerCase();
  if (n.endsWith('.pdf') || file.type === 'application/pdf') return extractPdf(file);
  if (n.endsWith('.docx')) return extractDocx(file);
  if (/\.(txt|md|markdown|csv|tsv|json|html?|srt|vtt)$/.test(n) || file.type.startsWith('text/')) {
    let t = await file.text();
    if (/\.html?$/.test(n)) t = htmlToText(t);
    return { text: t, pages: null };
  }
  throw new Error('Unsupported file type. Use PDF, DOCX, TXT, MD, CSV or HTML.');
}
async function fetchUrl(url) {
  const cap = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp;
  if (cap) { const r = await cap.get({ url, responseType: 'text' }); if (r.status >= 400) throw new Error('Page returned ' + r.status); return String(r.data); }
  const r = await fetch(url);
  if (!r.ok) throw new Error('Page returned ' + r.status);
  return r.text();
}

/* ---------- state ---------- */
const S = { nb: null, tab: 'sources', busy: false, noteView: null };

function newNotebook() {
  return { id: uid(), title: 'Untitled notebook', created: Date.now(), updated: Date.now(), sources: [], chat: [], notes: [] };
}
async function addSource(name, type, text, pages) {
  if (!text || !text.trim()) throw new Error('No readable text found (scanned PDFs need OCR, which is not included).');
  const id = uid();
  const chunks = buildChunks(id, text, pages);
  S.nb.sources.push({ id, name, type, enabled: true, chars: text.length, chunks, added: Date.now() });
  if (S.nb.title === 'Untitled notebook') S.nb.title = name.replace(/\.[^.]+$/, '').slice(0, 60);
  await putNotebook(S.nb);
}

/* ---------- views ---------- */
async function renderHome() {
  S.nb = null;
  const list = await allNotebooks();
  app.innerHTML = `
    <div class="topbar"><h1>📓 Notebook AI</h1><button class="icon-btn" data-act="settings" aria-label="Settings">⚙️</button></div>
    <div class="content">
      ${list.length ? list.map(n => `
        <div class="card" data-open="${n.id}">
          <div class="row"><div class="grow"><h3>${escapeHtml(n.title)}</h3>
          <div class="muted">${n.sources.length} source${n.sources.length === 1 ? '' : 's'} · ${n.notes.length} note${n.notes.length === 1 ? '' : 's'} · ${new Date(n.updated).toLocaleDateString()}</div></div>
          <button class="icon-btn" data-del="${n.id}" aria-label="Delete">🗑</button></div>
        </div>`).join('') : `<div class="empty"><div class="big">📓</div><p><b>Create your first notebook</b></p><p>Add PDFs, documents, web pages or pasted text, then chat with them and generate study guides, FAQs, flashcards and more. Every answer cites its sources.</p></div>`}
    </div>
    <button class="fab" data-act="new">＋ New notebook</button>`;
  if (!settings().apiKey) setTimeout(() => toast('Tip: add your OpenAI API key in ⚙️ Settings'), 400);
}

function header(title) {
  return `<div class="topbar"><button class="icon-btn" data-act="home" aria-label="Back">←</button>
    <h1 data-act="rename" title="Rename">${escapeHtml(title)}</h1>
    <button class="icon-btn" data-act="settings" aria-label="Settings">⚙️</button></div>`;
}
function tabsBar() {
  const t = [['sources', '📚', 'Sources'], ['chat', '💬', 'Chat'], ['studio', '✨', 'Studio'], ['notes', '🗒', 'Notes']];
  return '<div class="tabs">' + t.map(([k, i, l]) => `<button class="tab ${S.tab === k ? 'on' : ''}" data-tab="${k}"><span>${i}</span>${l}</button>`).join('') + '</div>';
}

function renderNotebook() {
  const nb = S.nb;
  let body = '';
  if (S.tab === 'sources') body = sourcesView();
  else if (S.tab === 'chat') body = chatView();
  else if (S.tab === 'studio') body = studioView();
  else body = notesView();
  app.innerHTML = header(nb.title) + `<div class="${S.tab === 'chat' ? '' : 'content'}" style="${S.tab === 'chat' ? 'flex:1;min-height:0' : ''}" id="body">${body}</div>` + tabsBar();
  if (S.tab === 'chat') { const m = $('#msgs'); if (m) m.scrollTop = m.scrollHeight; }
}

function sourcesView() {
  const nb = S.nb;
  const add = `<div class="chips">
    <button class="btn primary" data-act="addfile">＋ File</button>
    <button class="btn" data-act="addtext">Paste text</button>
    <button class="btn" data-act="addurl">Web link</button></div>
    <input type="file" id="filein" class="hidden" multiple accept=".pdf,.docx,.txt,.md,.markdown,.csv,.tsv,.json,.html,.htm,.srt,.vtt,text/*,application/pdf">`;
  if (!nb.sources.length) return add + `<div class="empty"><div class="big">📚</div><p><b>No sources yet</b></p><p>Add a PDF, Word file, text file, web page or pasted text. Answers and study material will come only from your sources.</p></div>`;
  return add + nb.sources.map(s => `
    <div class="card"><div class="row">
      <div class="grow" data-view="${s.id}"><h3>${escapeHtml(s.name)}</h3>
        <div class="muted"><span class="pill">${s.type}</span> ${s.chunks.length} passages · ${Math.round(s.chars / 1000)}k chars</div></div>
      <label class="switch"><input type="checkbox" data-toggle="${s.id}" ${s.enabled ? 'checked' : ''}><i></i></label>
      <button class="icon-btn" data-rm="${s.id}" aria-label="Remove">🗑</button></div></div>`).join('') +
    '<p class="muted">Toggle a source off to leave it out of chat and Studio.</p>';
}

function chatView() {
  const nb = S.nb;
  const msgs = nb.chat.map((m, i) => m.role === 'user'
    ? `<div class="bubble user">${escapeHtml(m.content)}</div>`
    : `<div class="bubble ai" data-i="${i}">${m.content ? renderMarkdown(m.content) : '<span class="typing">Thinking…</span>'}
        ${m.content && !m.streaming ? `<div class="bubble-actions"><button class="btn small" data-savemsg="${i}">Save to notes</button><button class="btn small" data-copymsg="${i}">Copy</button></div>` : ''}</div>`).join('');
  const empty = !nb.chat.length ? `<div class="empty"><div class="big">💬</div><p><b>Ask about your sources</b></p>
    <div class="chips" style="justify-content:center">${nb.sources.length ? '<button class="chip" data-suggest="1">✨ Suggest questions</button>' : ''}</div></div>` : '';
  return `<div class="chat"><div class="msgs" id="msgs">${empty}${msgs}</div>
    <div class="composer"><textarea id="q" rows="1" placeholder="${nb.sources.length ? 'Ask a question…' : 'Add a source first'}"></textarea>
    <button class="send" data-act="send" ${S.busy ? 'disabled' : ''} aria-label="Send">➤</button></div></div>`;
}

function studioView() {
  const nb = S.nb;
  const tiles = Object.entries(STUDIO).map(([k, v]) => `<button class="tile" data-gen="${k}" ${S.busy ? 'disabled' : ''}><span>${v.icon}</span><b>${v.label}</b></button>`).join('');
  return `<p class="muted">Generate study material from your enabled sources. Results are saved in Notes.</p>
    ${nb.sources.length ? '' : '<div class="card muted">Add a source first.</div>'}
    <div class="grid">${tiles}</div>
    ${S.busy ? '<p class="muted"><span class="spinner"></span> Generating…</p>' : ''}`;
}

function notesView() {
  const nb = S.nb;
  if (S.noteView) return noteDetail(nb.notes.find(n => n.id === S.noteView));
  if (!nb.notes.length) return `<div class="empty"><div class="big">🗒</div><p><b>No notes yet</b></p><p>Save chat answers or generate something in Studio.</p></div>
    <div class="chips"><button class="btn" data-act="newnote">＋ Write a note</button></div>`;
  return `<div class="chips"><button class="btn" data-act="newnote">＋ Write a note</button></div>` + nb.notes.slice().reverse().map(n => `
    <div class="card" data-note="${n.id}"><div class="row"><div class="grow"><h3>${escapeHtml(n.title)}</h3>
    <div class="muted"><span class="pill">${escapeHtml(n.label || 'Note')}</span> ${new Date(n.created).toLocaleString()}</div></div>
    <button class="icon-btn" data-delnote="${n.id}">🗑</button></div></div>`).join('');
}

function noteDetail(n) {
  if (!n) { S.noteView = null; return notesView(); }
  let body = '';
  if (n.kind === 'flashcards') body = n.data.cards.map((c, i) => `<div class="flip" data-flip="${i}"><div class="flip-in"><div class="face"><div><div class="muted">Question</div><b>${escapeHtml(c.q)}</b></div></div><div class="face back"><div><div class="muted">Answer</div>${escapeHtml(c.a)}</div></div></div></div>`).join('') + '<p class="muted">Tap a card to flip it.</p>';
  else if (n.kind === 'quiz') body = quizHtml(n);
  else if (n.kind === 'mindmap') body = '<div class="doc tree">' + treeHtml(n.data, 0) + '</div>';
  else body = `<div class="doc">${renderMarkdown(n.data)}</div>`;
  return `<div class="row" style="margin-bottom:10px"><button class="btn small" data-act="notesback">← Notes</button><div class="grow"></div>
    <button class="btn small" data-sharenote="${n.id}">Share</button></div><h3>${escapeHtml(n.title)}</h3>${body}`;
}
function treeHtml(node, depth) {
  const kids = node.children || [];
  if (!kids.length) return `<div class="leaf">${escapeHtml(node.title)}</div>`;
  return `<details ${depth < 2 ? 'open' : ''}><summary>${escapeHtml(node.title)}</summary>${kids.map(k => treeHtml(k, depth + 1)).join('')}</details>`;
}
function quizHtml(n) {
  const st = n.state || (n.state = {});
  const qs = n.data.questions;
  const answered = Object.keys(st).length;
  const score = qs.reduce((a, q, i) => a + (st[i] === q.answer ? 1 : 0), 0);
  return qs.map((q, i) => `<div class="card"><b>${i + 1}. ${escapeHtml(q.q)}</b>
    ${q.options.map((o, j) => {
      let cls = '';
      if (st[i] !== undefined) { if (j === q.answer) cls = 'good'; else if (j === st[i]) cls = 'bad'; }
      return `<button class="opt ${cls}" data-q="${i}" data-o="${j}" ${st[i] !== undefined ? 'disabled' : ''}>${escapeHtml(o)}</button>`;
    }).join('')}
    ${st[i] !== undefined && q.explanation ? `<div class="muted">${escapeHtml(q.explanation)}</div>` : ''}</div>`).join('') +
    `<div class="card"><b>Score: ${score} / ${qs.length}</b>${answered === qs.length ? '' : `<div class="muted">${answered} answered</div>`}
    ${answered ? '<button class="btn small" data-act="quizreset">Retry</button>' : ''}</div>`;
}

/* ---------- actions ---------- */
function activeChunks(query) {
  const nb = S.nb;
  const enabled = nb.sources.filter(s => s.enabled);
  if (!enabled.length) return null;
  const total = enabled.reduce((a, s) => a + s.chars, 0);
  if (total <= 24000) return coverageChunks(nb.sources, 24000);
  const all = enabled.flatMap(s => s.chunks.map(c => ({ ...c, srcName: s.name })));
  return searchChunks(all, query, 10);
}

async function ask(question) {
  const nb = S.nb;
  if (S.busy || !question.trim()) return;
  const chunks = activeChunks(question + ' ' + (nb.chat.filter(m => m.role === 'user').slice(-1)[0] || { content: '' }).content);
  if (!chunks) { toast('Add or enable a source first'); return; }
  const { text, cites } = formatPassages(chunks);
  const history = nb.chat.filter(m => m.content && !m.error).slice(-6).map(m => ({ role: m.role, content: m.content }));
  nb.chat.push({ role: 'user', content: question });
  const reply = { role: 'assistant', content: '', cites, streaming: true };
  nb.chat.push(reply);
  S.busy = true; renderNotebook();
  try {
    const out = await callAI([
      { role: 'system', content: SYSTEM_CHAT },
      ...history,
      { role: 'user', content: 'SOURCE PASSAGES:\n' + text + '\n\nQUESTION: ' + question },
    ], { onToken: t => { reply.content = t; const el = document.querySelector('.bubble.ai:last-child'); if (el) { el.innerHTML = renderMarkdown(t); const m = $('#msgs'); if (m) m.scrollTop = m.scrollHeight; } } });
    reply.content = out || 'No answer returned.';
  } catch (e) {
    reply.content = '⚠️ ' + e.message; reply.error = true; reply.cites = {};
  }
  reply.streaming = false; S.busy = false;
  await putNotebook(nb);
  if (S.tab === 'chat') renderNotebook();
}

async function suggestQuestions() {
  const chunks = activeChunks('overview');
  if (!chunks) return toast('Add a source first');
  S.busy = true; toast('Thinking of questions…');
  try {
    const { text } = formatPassages(chunks.slice(0, 12));
    const out = await callAI([
      { role: 'system', content: 'Suggest useful questions a reader could ask about the sources. Return JSON: {"questions": [5 short strings]}.' },
      { role: 'user', content: text },
    ], { json: true });
    const qs = parseJSONLoose(out).questions || [];
    S.busy = false; renderNotebook();
    $('#msgs').insertAdjacentHTML('afterbegin', '<div class="chips">' + qs.map(q => `<button class="chip" data-ask="${escapeHtml(q)}">${escapeHtml(q)}</button>`).join('') + '</div>');
  } catch (e) { S.busy = false; toast(e.message); renderNotebook(); }
}

async function generate(key) {
  const nb = S.nb, def = STUDIO[key];
  if (S.busy) return;
  const chunks = coverageChunks(nb.sources, 60000);
  if (!chunks.length) return toast('Add or enable a source first');
  const { text, cites } = formatPassages(chunks);
  S.busy = true; renderNotebook();
  try {
    const out = await callAI([
      { role: 'system', content: SYSTEM_STUDIO },
      { role: 'user', content: def.prompt + '\n\nSOURCE PASSAGES:\n' + text },
    ], { json: def.kind === 'json' });
    let data = out;
    if (def.kind === 'json') {
      data = parseJSONLoose(out);
      if (key === 'flashcards' && !Array.isArray(data.cards)) throw new Error('Unexpected flashcard format. Try again.');
      if (key === 'quiz' && !Array.isArray(data.questions)) throw new Error('Unexpected quiz format. Try again.');
      if (key === 'mindmap' && !data.title) throw new Error('Unexpected mind map format. Try again.');
    }
    const note = { id: uid(), title: def.label + ' – ' + nb.title, label: def.label, kind: key === 'flashcards' || key === 'quiz' || key === 'mindmap' ? key : 'md', data, cites, created: Date.now() };
    nb.notes.push(note);
    await putNotebook(nb);
    S.busy = false; S.tab = 'notes'; S.noteView = note.id; renderNotebook();
  } catch (e) { S.busy = false; renderNotebook(); toast(e.message); }
}

function showCite(n, cites) {
  const c = cites && cites[n];
  if (!c) return toast('Passage not available');
  openSheet(`<h3>${escapeHtml(c.name || 'Source')}${c.page ? ' · page ' + c.page : ''}</h3><p style="white-space:pre-wrap">${escapeHtml(c.text)}</p><button class="btn" data-act="closesheet">Close</button>`);
}

function settingsSheet() {
  const s = settings();
  openSheet(`<h3>Settings</h3>
    <label>OpenAI API key</label><input type="password" id="s-key" value="${escapeHtml(s.apiKey)}" placeholder="sk-..." autocomplete="off">
    <label>Model</label><input type="text" id="s-model" value="${escapeHtml(s.model)}" list="models">
    <datalist id="models"><option value="gpt-4o-mini"><option value="gpt-4o"><option value="gpt-4.1-mini"><option value="gpt-4.1"></datalist>
    <label>API base URL (optional, for compatible providers)</label><input type="text" id="s-url" value="${escapeHtml(s.baseUrl)}">
    <p class="muted">Your key is stored only on this device and sent only to the API address above. Your sources are sent to that service when you chat or generate.</p>
    <div class="row" style="margin-bottom:10px"><button class="btn grow" data-act="testconn">Test connection</button></div>
    <p id="s-result" class="muted"></p>
    <div class="row"><button class="btn primary grow" data-act="savesettings">Save</button><button class="btn" data-act="closesheet">Cancel</button></div>`);
}

/* ---------- events ---------- */
document.addEventListener('click', async e => {
  const t = e.target.closest('[data-act],[data-open],[data-del],[data-tab],[data-rm],[data-view],[data-gen],[data-note],[data-delnote],[data-flip],[data-q],[data-savemsg],[data-copymsg],[data-ask],[data-suggest],[data-sharenote],.cite');
  if (!t || t.matches('input')) return;
  const d = t.dataset;
  try {
    if (t.classList.contains('cite')) {
      const bubble = t.closest('.bubble'), note = t.closest('.doc');
      const cites = bubble ? S.nb.chat[+bubble.dataset.i].cites : (S.nb.notes.find(n => n.id === S.noteView) || {}).cites;
      return showCite(t.dataset.n, cites);
    }
    if (d.open) { S.nb = (await allNotebooks()).find(n => n.id === d.open); S.tab = S.nb.sources.length ? 'chat' : 'sources'; S.noteView = null; return renderNotebook(); }
    if (d.del) { e.stopPropagation(); if (confirm('Delete this notebook and all its sources?')) { await removeNotebook(d.del); renderHome(); } return; }
    if (d.tab) { S.tab = d.tab; S.noteView = null; return renderNotebook(); }
    if (d.rm) { if (confirm('Remove this source?')) { S.nb.sources = S.nb.sources.filter(s => s.id !== d.rm); await putNotebook(S.nb); renderNotebook(); } return; }
    if (d.view) { const s = S.nb.sources.find(x => x.id === d.view); return openSheet(`<h3>${escapeHtml(s.name)}</h3><p class="muted">${s.chunks.length} passages</p><p style="white-space:pre-wrap">${escapeHtml(s.chunks.map(c => c.text).join('\n\n').slice(0, 6000))}${s.chars > 6000 ? '\n\n…' : ''}</p><button class="btn" data-act="closesheet">Close</button>`); }
    if (d.gen) return generate(d.gen);
    if (d.note) { S.noteView = d.note; return renderNotebook(); }
    if (d.delnote) { e.stopPropagation(); if (confirm('Delete this note?')) { S.nb.notes = S.nb.notes.filter(n => n.id !== d.delnote); await putNotebook(S.nb); renderNotebook(); } return; }
    if (d.flip !== undefined) return t.classList.toggle('on');
    if (d.q !== undefined) { const n = S.nb.notes.find(x => x.id === S.noteView); n.state[d.q] = +d.o; await putNotebook(S.nb); return renderNotebook(); }
    if (d.savemsg !== undefined) { const m = S.nb.chat[+d.savemsg]; const q = S.nb.chat[+d.savemsg - 1]; S.nb.notes.push({ id: uid(), title: (q ? q.content : 'Chat answer').slice(0, 60), label: 'Chat', kind: 'md', data: m.content, cites: m.cites, created: Date.now() }); await putNotebook(S.nb); return toast('Saved to Notes'); }
    if (d.copymsg !== undefined) return shareText('Answer', S.nb.chat[+d.copymsg].content);
    if (d.ask) return ask(d.ask);
    if (d.suggest) return suggestQuestions();
    if (d.sharenote) { const n = S.nb.notes.find(x => x.id === d.sharenote); return shareText(n.title, typeof n.data === 'string' ? n.data : JSON.stringify(n.data, null, 2)); }

    switch (d.act) {
      case 'new': S.nb = newNotebook(); await putNotebook(S.nb); S.tab = 'sources'; return renderNotebook();
      case 'home': return renderHome();
      case 'settings': return settingsSheet();
      case 'closesheet': return closeSheet();
      case 'testconn': {
        const out = $('#s-result'); out.textContent = 'Testing…';
        out.textContent = await testConnection($('#s-key').value.trim(), $('#s-url').value.trim() || 'https://api.openai.com/v1');
        return;
      }
      case 'savesettings': saveSettings({ apiKey: $('#s-key').value.trim(), model: $('#s-model').value.trim() || 'gpt-4o-mini', baseUrl: $('#s-url').value.trim() || 'https://api.openai.com/v1' }); closeSheet(); return toast('Settings saved');
      case 'rename': { const n = prompt('Notebook name', S.nb.title); if (n && n.trim()) { S.nb.title = n.trim().slice(0, 80); await putNotebook(S.nb); renderNotebook(); } return; }
      case 'addfile': return $('#filein').click();
      case 'addtext': return openSheet(`<h3>Paste text</h3><label>Title</label><input type="text" id="t-title" placeholder="Pasted text"><label>Text</label><textarea id="t-body" rows="8"></textarea><div class="row" style="margin-top:12px"><button class="btn primary grow" data-act="savetext">Add source</button><button class="btn" data-act="closesheet">Cancel</button></div>`);
      case 'savetext': { const body = $('#t-body').value; const title = $('#t-title').value.trim() || 'Pasted text'; await addSource(title, 'text', body); closeSheet(); return renderNotebook(); }
      case 'addurl': return openSheet(`<h3>Add a web link</h3><input type="url" id="u-url" placeholder="https://example.com/article"><p class="muted">The page text is imported once. Pages that need a login or are built entirely by scripts may not import.</p><div class="row"><button class="btn primary grow" data-act="saveurl">Import</button><button class="btn" data-act="closesheet">Cancel</button></div>`);
      case 'saveurl': {
        const url = $('#u-url').value.trim(); if (!/^https?:\/\//i.test(url)) return toast('Enter a full http(s) link');
        toast('Importing…');
        const html = await fetchUrl(url);
        const text = htmlToText(html);
        await addSource(titleFromHtml(html) || url, 'web', text);
        closeSheet(); return renderNotebook();
      }
      case 'send': { const q = $('#q'); const v = q.value; q.value = ''; return ask(v); }
      case 'notesback': S.noteView = null; return renderNotebook();
      case 'newnote': return openSheet(`<h3>New note</h3><input type="text" id="n-title" placeholder="Title"><label>Note</label><textarea id="n-body" rows="8"></textarea><div class="row" style="margin-top:12px"><button class="btn primary grow" data-act="savenote">Save</button><button class="btn" data-act="closesheet">Cancel</button></div>`);
      case 'savenote': { const body = $('#n-body').value.trim(); if (!body) return; S.nb.notes.push({ id: uid(), title: $('#n-title').value.trim() || 'Note', label: 'Note', kind: 'md', data: body, cites: {}, created: Date.now() }); await putNotebook(S.nb); closeSheet(); return renderNotebook(); }
      case 'quizreset': { const n = S.nb.notes.find(x => x.id === S.noteView); n.state = {}; await putNotebook(S.nb); return renderNotebook(); }
    }
  } catch (err) { toast(err.message || 'Something went wrong'); }
});

document.addEventListener('change', async e => {
  const t = e.target;
  if (t.dataset.toggle) { const s = S.nb.sources.find(x => x.id === t.dataset.toggle); s.enabled = t.checked; await putNotebook(S.nb); }
  if (t.id === 'filein' && t.files.length) {
    const files = [...t.files];
    for (const f of files) {
      try { toast('Reading ' + f.name + '…'); const r = await extractFile(f); await addSource(f.name, (f.name.split('.').pop() || 'file').toLowerCase(), r.text, r.pages); }
      catch (err) { toast(f.name + ': ' + err.message); await new Promise(r => setTimeout(r, 1800)); }
    }
    renderNotebook();
  }
});

document.addEventListener('keydown', e => {
  if (e.target.id === 'q' && e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); const v = e.target.value; e.target.value = ''; ask(v); }
});

// Android back button: close sheet, then go up one level.
document.addEventListener('backbutton', () => { if (!$('#modal').classList.contains('hidden')) closeSheet(); else if (S.noteView) { S.noteView = null; renderNotebook(); } else if (S.nb) renderHome(); });

renderHome();
