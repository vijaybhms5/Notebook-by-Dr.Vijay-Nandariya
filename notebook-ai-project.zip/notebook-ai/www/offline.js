// Offline engine: answers and study material built from the user's own text, with no AI service and no key.
// It selects and arranges sentences from the sources (extractive), so everything it shows is quotable and cited.
import { tokenize, rawTokens, stem, STOP } from './core.js';

const WORD = /[\p{L}\p{M}\p{N}]+/gu;
const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const clean = t => String(t).replace(/\[(\d{1,3})\]/g, '($1)').replace(/[*`]/g, '').replace(/\s+/g, ' ').trim();
const snip = (t, n) => { const c = clean(t); return c.length > n ? c.slice(0, n - 1).trimEnd() + '…' : c; };
const cap = w => w.charAt(0).toUpperCase() + w.slice(1);
const jac = (a, b) => { const A = new Set(a), B = new Set(b); let i = 0; for (const x of A) if (B.has(x)) i++; return i / ((A.size + B.size - i) || 1); };

/* ---------- sentences ---------- */
const ABBR = /\b(?:Dr|Mr|Mrs|Ms|Prof|St|vs|etc|No|Fig|Sr|Jr|e\.g|i\.e)\.$/;

export function splitSentences(text) {
  const out = [];
  for (const line of String(text || '').replace(/\r/g, '').split(/\n+/)) {
    const l = line.replace(/[ \t]+/g, ' ').trim();
    if (!l) continue;
    let buf = '';
    for (const p of l.split(/(?<=[.!?।]["')\]]*)\s+(?=\S)/)) {
      buf = buf ? buf + ' ' + p : p;
      if (ABBR.test(buf)) continue;
      out.push(buf); buf = '';
    }
    if (buf) out.push(buf);
  }
  return out;
}

export function sentencesOf(chunks) {
  const out = [];
  chunks.forEach((c, ci) => splitSentences(c.text).forEach((t, si) => {
    out.push({ text: t, c, ci, si, words: t.split(/\s+/).length, stems: tokenize(t), raw: rawTokens(t) });
  }));
  return out;
}

/** Hands out citation numbers in order of first use, and remembers the passage behind each. */
function makeCiter() {
  const map = new Map(), cites = {};
  return {
    cites,
    cite(c) {
      if (!map.has(c)) { const n = map.size + 1; map.set(c, n); cites[n] = { src: c.src, name: c.srcName || '', page: c.page || null, text: c.text }; }
      return '[' + map.get(c) + ']';
    },
  };
}

/* ---------- analysis ---------- */
function analyze(sents) {
  const N = sents.length || 1, df = new Map(), tf = new Map(), surf = new Map();
  for (const s of sents) {
    const seen = new Set();
    s.stems.forEach((st, i) => {
      if (st.length < 3 || /^\p{N}+$/u.test(st)) return;
      tf.set(st, (tf.get(st) || 0) + 1);
      if (!seen.has(st)) { seen.add(st); df.set(st, (df.get(st) || 0) + 1); }
      let m = surf.get(st); if (!m) surf.set(st, m = new Map());
      m.set(s.raw[i], (m.get(s.raw[i]) || 0) + 1);
    });
  }
  const small = [...tf.values()].filter(f => f >= 2).length < 6;
  const weight = new Map();
  for (const [st, f] of tf) if (f >= 2 || small) weight.set(st, (1 + Math.log(f)) * Math.log(1 + N / df.get(st)));
  const best = st => [...surf.get(st).entries()].sort((a, b) => b[1] - a[1])[0][0];
  const kws = [...weight.entries()].map(([st, w]) => ({ stem: st, word: best(st), w })).filter(k => k.word.length >= 4).sort((a, b) => b.w - a.w);
  const score = s => {
    const u = [...new Set(s.stems)];
    let t = 0; for (const st of u) t += weight.get(st) || 0;
    t /= Math.pow(Math.max(u.length, 1), 0.6);
    if (s.words < 6 || s.words > 45) t *= 0.25;
    if (PRON.test(s.text)) t *= 0.35;
    return t;
  };
  return { sents, kws, weight, score };
}

function top(a, k, filter = () => true) {
  const ranked = a.sents.filter(filter).map(s => ({ s, sc: a.score(s) })).filter(r => r.sc > 0).sort((x, y) => y.sc - x.sc);
  const out = [];
  for (const r of ranked) {
    if (out.length >= k) break;
    if (out.every(o => jac(o.stems, r.s.stems) < 0.6)) out.push(r.s);
  }
  return out;
}
const inOrder = arr => arr.slice().sort((a, b) => a.ci - b.ci || a.si - b.si);
const PRON = /^(he|she|it|they|his|her|its|their|this|that|these|those|such|however|also|then|thus)\b/i;
const standalone = s => !PRON.test(s.text);
const goodLen = s => s.words >= 6 && s.words <= 45 && standalone(s);

const DEF = /^(an?\s+|the\s+)?([\p{L}\p{N}][\p{L}\p{M}\p{N}\s'-]{1,50}?)\s+(is|are|was|were|means|refers to)\s+(.{12,})$/iu;
function definitions(sents) {
  const out = [], seen = new Set();
  for (const s of sents) {
    if (s.words < 6 || s.words > 50) continue;
    const m = s.text.replace(/[.!?।]+$/, '').match(DEF);
    if (!m) continue;
    const art = /^the\s/i.test(m[1] || '') ? 'the ' : '', term = m[2].trim(), verb = /^(is|are|was|were)$/i.test(m[3]) ? m[3].toLowerCase() : 'is';
    if (term.split(/\s+/).length > 5 || /^(it|this|that|they|he|she|there|these|those|which|who|what)$/i.test(term)) continue;
    const key = term.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); out.push({ term, art, verb, def: m[4].trim(), s });
  }
  return out;
}

/* ---------- deterministic shuffle ---------- */
function rng(seedText) {
  let h = 2166136261;
  for (let i = 0; i < seedText.length; i++) { h ^= seedText.charCodeAt(i); h = Math.imul(h, 16777619); }
  return () => { h |= 0; h = (h + 0x6D2B79F5) | 0; let t = Math.imul(h ^ (h >>> 15), 1 | h); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function shuffle(arr, r) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

/** Choose a word or number in the sentence to hide. */
function blank(s, a) {
  let best = null;
  s.text.replace(WORD, (w, off) => {
    const lw = w.toLowerCase();
    let sc = 0;
    if (/^\d{3,4}$/.test(w)) sc = 100;
    else if (w.length >= 4 && !STOP.has(lw) && !/^\d+$/.test(w)) sc = a.weight.get(stem(lw)) || 0;
    if (off === 0) sc *= 0.5;
    const before = s.text[off - 1], after = s.text[off + w.length];
    if (before === '-' || after === '-' || before === "'" || before === '’' || after === "'" || after === '’') sc = 0;
    if (sc > 0 && (!best || sc > best.sc)) best = { w, off, sc };
    return w;
  });
  if (!best) return null;
  return {
    q: s.text.slice(0, best.off) + '_____' + s.text.slice(best.off + best.w.length),
    answer: best.w, numeric: /^\d+$/.test(best.w), stem: stem(best.w.toLowerCase()),
  };
}

function distractors(b, a, s, r) {
  const out = [];
  if (b.numeric) {
    const n = +b.answer;
    const pool = [...new Set(a.sents.flatMap(x => x.text.match(/\b\d{3,4}\b/g) || []))].filter(x => x !== b.answer);
    out.push(...shuffle(pool, r).slice(0, 3));
    for (const o of [-10, 10, -3, 3, -25, 25, 1, -1]) {
      if (out.length >= 3) break;
      const v = String(n + o);
      if (n + o > 0 && v !== b.answer && !out.includes(v)) out.push(v);
    }
    return out.length >= 3 ? out : null;
  }
  const isCap = /^\p{Lu}/u.test(b.answer);
  const pool = a.kws.filter(k => k.stem !== b.stem && !s.stems.includes(k.stem)).slice(0, 30).map(k => k.word);
  for (const w of shuffle(pool, r)) { if (out.length >= 3) break; out.push(isCap ? cap(w) : w); }
  return out.length >= 3 ? out : null;
}

/* ---------- chat ---------- */
function rankSentences(sents, q, boost) {
  const N = sents.length, avg = sents.reduce((t, s) => t + s.stems.length, 0) / N || 1;
  const df = new Map();
  sents.forEach(s => new Set(s.stems).forEach(t => df.set(t, (df.get(t) || 0) + 1)));
  const k1 = 1.4, b = 0.75;
  return sents.map(s => {
    const tf = new Map(); s.stems.forEach(t => tf.set(t, (tf.get(t) || 0) + 1));
    let score = 0, hit = 0;
    for (const t of q) {
      const f = tf.get(t) || 0;
      if (!f) continue;
      hit++;
      const n = df.get(t) || 0;
      score += Math.log(1 + (N - n + 0.5) / (n + 0.5)) * (f * (k1 + 1)) / (f + k1 * (1 - b + b * s.stems.length / avg));
    }
    score *= 1 + 0.6 * (hit / q.length);
    if (boost) score *= boost(s);
    return { s, score, hit };
  }).filter(r => r.score > 0).sort((x, y) => y.score - x.score);
}

function highlight(text, qset) {
  return clean(text).replace(WORD, w => (qset.has(stem(w.toLowerCase())) ? '**' + w + '**' : w));
}

/** Answer a question by quoting the most relevant sentences from the sources. */
export function answerOffline(question, chunks) {
  const { cite, cites } = makeCiter();
  const sents = sentencesOf(chunks);
  if (!sents.length) return { md: 'Your sources have no readable text yet.', cites };
  if (/\b(summar|overview|main (idea|points?)|key points?|gist|tl;?dr)/i.test(question)) {
    const r = offlineStudio('summary', chunks, '');
    return { md: r.data, cites: r.cites };
  }
  const q = [...new Set(tokenize(question))];
  if (!q.length) return { md: 'Try asking with a few specific words, for example a name, term or topic from your sources.', cites };
  const dm = question.match(/^\s*(?:what\s+(?:is|are|was|were)|who\s+(?:is|was)|define|meaning of)\s+(?:an?\s+|the\s+)?(.+?)\s*\??\s*$/i);
  const defRe = dm ? new RegExp('\\b' + esc(dm[1]) + '\\b\\s+(?:is|are|was|were|means|refers to)\\b', 'i') : null;
  const ranked = rankSentences(sents, q, defRe ? s => (defRe.test(s.text) ? 2 : 1) : null);
  const picks = [];
  for (const r of ranked) {
    if (picks.length >= 6) break;
    if (r.s.words < 3) continue;
    if (picks.every(p => jac(p.s.stems, r.s.stems) < 0.7)) picks.push(r);
  }
  if (!picks.length) {
    return { md: 'I could not find that in your sources. Try different words, or add a source that covers it.', cites };
  }
  const qset = new Set(q);
  const lines = picks.map(p => '- ' + highlight(p.s.text, qset) + ' ' + cite(p.s.c));
  const weak = picks[0].hit < Math.ceil(q.length / 2);
  return { md: 'Most relevant passages from your sources:\n\n' + lines.join('\n') + (weak ? '\n\n*Only partial matches found. Try other words.*' : ''), cites };
}

export function suggestOffline(chunks) {
  const sents = sentencesOf(chunks);
  if (!sents.length) return [];
  const a = analyze(sents);
  const defs = definitions(sents);
  const qs = defs.slice(0, 2).map(d => 'What ' + d.verb + ' ' + d.art + d.term + '?');
  for (const k of a.kws) {
    if (qs.length >= 5) break;
    if (defs.some(d => d.term.toLowerCase().includes(k.word))) continue;
    qs.push('What do the sources say about ' + k.word + '?');
  }
  return qs;
}

/* ---------- studio ---------- */
const need = (cond, msg) => { if (!cond) throw new Error(msg); };
const NOT_ENOUGH = 'There is not enough text in your sources to build this offline.';

/**
 * Build study material without an AI service.
 * Returns { data, cites }. `data` is Markdown for text outputs, or an object for flashcards, quiz and mind map.
 */
export function offlineStudio(key, chunks, title = '') {
  const sents = sentencesOf(chunks);
  need(sents.length >= 3, NOT_ENOUGH);
  const a = analyze(sents);
  const { cite, cites } = makeCiter();
  const bullet = s => '- ' + clean(s.text) + ' ' + cite(s.c);

  if (key === 'summary') {
    const picks = top(a, 8, goodLen);
    need(picks.length, NOT_ENOUGH);
    const main = picks[0];
    const rest = inOrder(picks.slice(1));
    return { cites, data: '## Summary\n\n' + clean(main.text) + ' ' + cite(main.c) + (rest.length ? '\n\n## Key points\n\n' + rest.map(bullet).join('\n') : '') };
  }

  if (key === 'briefing') {
    const over = inOrder(top(a, 3, goodLen));
    need(over.length, NOT_ENOUGH);
    let md = '## Overview\n\n' + over.map(s => clean(s.text) + ' ' + cite(s.c)).join(' ') + '\n\n## Key themes\n\n';
    const used = new Set(over);
    const themes = [];
    for (const k of a.kws.slice(0, 14)) {
      if (themes.length >= 5) break;
      const s = a.sents.filter(x => !used.has(x) && x.stems.includes(k.stem) && goodLen(x)).sort((x, y) => a.score(y) - a.score(x))[0];
      if (!s) continue;
      used.add(s); themes.push('- **' + cap(k.word) + '**: ' + clean(s.text) + ' ' + cite(s.c));
    }
    md += themes.join('\n');
    const facts = inOrder(top(a, 6, s => /\d/.test(s.text) && goodLen(s) && !used.has(s)));
    if (facts.length) md += '\n\n## Important details\n\n' + facts.map(bullet).join('\n');
    md += '\n\n## Questions to explore\n\n' + a.kws.slice(0, 3).map(k => '- What do the sources say about ' + k.word + '?').join('\n');
    return { cites, data: md };
  }

  if (key === 'study') {
    const defs = definitions(sents).slice(0, 8);
    let md = '## Key concepts\n\n';
    if (defs.length) md += defs.map(d => '- **' + cap(d.term) + '**: ' + clean(d.def) + ' ' + cite(d.s.c)).join('\n');
    else {
      const used = new Set(), lines = [];
      for (const k of a.kws.slice(0, 8)) {
        const s = a.sents.filter(x => !used.has(x) && x.stems.includes(k.stem) && goodLen(x)).sort((x, y) => a.score(y) - a.score(x))[0];
        if (s) { used.add(s); lines.push('- **' + cap(k.word) + '**: ' + clean(s.text) + ' ' + cite(s.c)); }
      }
      need(lines.length, NOT_ENOUGH);
      md += lines.join('\n');
    }
    const facts = inOrder(top(a, 6, s => /\d/.test(s.text) && goodLen(s)));
    if (facts.length) md += '\n\n## Important facts\n\n' + facts.map(bullet).join('\n');
    const qs = top(a, 6, goodLen).map(s => ({ s, b: blank(s, a) })).filter(x => x.b);
    if (qs.length) md += '\n\n## Practice questions\n\n' + qs.map((x, i) => (i + 1) + '. ' + clean(x.b.q) + ' **Answer:** ' + x.b.answer + ' ' + cite(x.s.c)).join('\n');
    md += '\n\n## Key terms\n\n' + a.kws.slice(0, 12).map(k => k.word).join(', ');
    return { cites, data: md };
  }

  if (key === 'faq') {
    const items = [], used = new Set();
    for (const d of definitions(sents)) { if (items.length >= 5) break; used.add(d.s); items.push({ q: 'What ' + d.verb + ' ' + d.art + d.term + '?', s: d.s }); }
    for (const k of a.kws.slice(0, 20)) {
      if (items.length >= 10) break;
      const s = a.sents.filter(x => !used.has(x) && x.stems.includes(k.stem) && goodLen(x)).sort((x, y) => a.score(y) - a.score(x))[0];
      if (!s) continue;
      used.add(s); items.push({ q: 'What do the sources say about ' + k.word + '?', s });
    }
    need(items.length, NOT_ENOUGH);
    return { cites, data: items.map(i => '### ' + i.q + '\n\n' + clean(i.s.text) + ' ' + cite(i.s.c)).join('\n\n') };
  }

  if (key === 'timeline') {
    const YEAR = /\b(1[0-9]{3}|20[0-9]{2})\b/;
    const items = sents.filter(s => YEAR.test(s.text) && s.words >= 4 && s.words <= 60).map(s => ({ y: +s.text.match(YEAR)[1], s }));
    need(items.length, 'No years or dates were found in your sources.');
    items.sort((p, q) => p.y - q.y || p.s.ci - q.s.ci || p.s.si - q.s.si);
    const seen = new Set(), keep = [];
    for (const it of items) { if (!seen.has(it.s.text)) { seen.add(it.s.text); keep.push(it); } }
    return { cites, data: '## Timeline\n\n' + keep.slice(0, 25).map(i => '- **' + i.y + '** — ' + clean(i.s.text) + ' ' + cite(i.s.c)).join('\n') };
  }

  if (key === 'mindmap') {
    const used = new Set(), children = [];
    for (const k of a.kws.slice(0, 12)) {
      if (children.length >= 6) break;
      const ss = a.sents.filter(x => x.stems.includes(k.stem) && x.words >= 5 && !used.has(x)).sort((x, y) => a.score(y) - a.score(x)).slice(0, 3);
      if (!ss.length) continue;
      ss.forEach(x => used.add(x));
      children.push({ title: cap(k.word), children: ss.map(x => ({ title: snip(x.text, 90) })) });
    }
    need(children.length, NOT_ENOUGH);
    return { cites: {}, data: { title: title || 'Notebook', children } };
  }

  if (key === 'flashcards') {
    const cards = [], used = new Set();
    for (const d of definitions(sents)) { if (cards.length >= 8) break; used.add(d.s); cards.push({ q: 'What ' + d.verb + ' ' + d.art + d.term + '?', a: snip(d.def, 220) }); }
    for (const s of top(a, 24, goodLen)) {
      if (cards.length >= 18) break;
      if (used.has(s)) continue;
      const b = blank(s, a);
      if (b) cards.push({ q: 'Fill in the blank: ' + snip(b.q, 220), a: b.answer });
    }
    need(cards.length >= 2, NOT_ENOUGH);
    return { cites: {}, data: { cards } };
  }

  if (key === 'quiz') {
    const questions = [];
    for (const s of top(a, 30, s => s.words >= 7 && s.words <= 40 && standalone(s))) {
      if (questions.length >= 10) break;
      const b = blank(s, a);
      if (!b) continue;
      const r = rng(s.text);
      const d = distractors(b, a, s, r);
      if (!d) continue;
      const options = shuffle([b.answer, ...d], r);
      questions.push({ q: 'Fill in the blank: ' + snip(b.q, 240), options, answer: options.indexOf(b.answer), explanation: 'From your sources: ' + snip(s.text, 200) });
    }
    need(questions.length >= 2, NOT_ENOUGH);
    return { cites: {}, data: { questions } };
  }

  throw new Error('Unknown output type.');
}
