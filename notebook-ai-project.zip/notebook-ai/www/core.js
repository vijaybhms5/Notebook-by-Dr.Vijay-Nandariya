// Pure logic: chunking, retrieval, prompts, markdown. No DOM access, so it can be tested in Node.

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

export function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Split text into passages of roughly `size` characters, preferring paragraph/sentence breaks. */
export function chunkText(text, size = 900) {
  const clean = String(text || '').replace(/\r/g, '').replace(/[ \t]+/g, ' ').trim();
  if (!clean) return [];
  const paras = clean.split(/\n{2,}/).map(p => p.trim()).filter(Boolean);
  const out = [];
  let cur = '';
  const push = () => { if (cur.trim()) out.push(cur.trim()); cur = ''; };
  for (const p of paras) {
    if (p.length > size) {
      push();
      const sentences = p.match(/[^.!?\n]+[.!?]+["')\]]*\s*|[^.!?\n]+$/g) || [p];
      for (const s of sentences) {
        if (s.length > size * 1.5) {
          for (let i = 0; i < s.length; i += size) out.push(s.slice(i, i + size).trim());
        } else if ((cur + s).length > size) { push(); cur = s; }
        else cur += s;
      }
      push();
    } else if ((cur + '\n\n' + p).length > size) { push(); cur = p; }
    else cur = cur ? cur + '\n\n' + p : p;
  }
  push();
  return out;
}

/** Build chunks for a source. `pages` is optional: [{page, text}]. */
export function buildChunks(sourceId, text, pages) {
  const chunks = [];
  const add = (t, page) => chunkText(t).forEach(c => chunks.push({ id: sourceId + '-' + chunks.length, src: sourceId, page: page || null, text: c }));
  if (pages && pages.length) pages.forEach(p => add(p.text, p.page));
  else add(text, null);
  return chunks;
}

const STOP = new Set('a an the and or but if then of to in on at by for with from as is are was were be been it its this that these those i you he she we they what which who whom how why when where do does did not no yes can could should would will about into over than so such also'.split(' '));

export function tokenize(s) {
  return (String(s).toLowerCase().match(/[\p{L}\p{N}]+/gu) || []).filter(t => t.length > 1 && !STOP.has(t));
}

/** BM25 ranking over chunk objects. Returns top-k chunks with scores. */
export function searchChunks(chunks, query, k = 8) {
  const q = tokenize(query);
  if (!q.length || !chunks.length) return chunks.slice(0, k);
  const docs = chunks.map(c => tokenize(c.text));
  const N = docs.length;
  const avg = docs.reduce((a, d) => a + d.length, 0) / N || 1;
  const df = new Map();
  docs.forEach(d => new Set(d).forEach(t => df.set(t, (df.get(t) || 0) + 1)));
  const k1 = 1.4, b = 0.75;
  const scored = chunks.map((c, i) => {
    const d = docs[i];
    const tf = new Map();
    d.forEach(t => tf.set(t, (tf.get(t) || 0) + 1));
    let score = 0;
    for (const t of new Set(q)) {
      const f = tf.get(t) || 0;
      if (!f) continue;
      const n = df.get(t) || 0;
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
      score += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * d.length / avg));
    }
    return { c, score };
  });
  scored.sort((a, b2) => b2.score - a.score);
  const hits = scored.filter(s => s.score > 0).slice(0, k).map(s => s.c);
  return hits.length ? hits : chunks.slice(0, k);
}

/** Pick chunks to cover a whole notebook within a character budget (evenly sampled per source). */
export function coverageChunks(sources, budget = 60000) {
  const active = sources.filter(s => s.enabled !== false && s.chunks && s.chunks.length);
  const total = active.reduce((a, s) => a + s.chunks.reduce((x, c) => x + c.text.length, 0), 0);
  if (total <= budget) return active.flatMap(s => s.chunks.map(c => ({ ...c, srcName: s.name })));
  const perSource = Math.floor(budget / active.length);
  const out = [];
  for (const s of active) {
    const stride = Math.max(1, Math.ceil(s.chunks.reduce((x, c) => x + c.text.length, 0) / perSource));
    let used = 0;
    s.chunks.forEach((c, i) => {
      if (i % stride === 0 && used + c.text.length <= perSource) { out.push({ ...c, srcName: s.name }); used += c.text.length; }
    });
  }
  return out;
}

/** Number passages [1..n] and return prompt text plus a citation lookup. */
export function formatPassages(chunks) {
  const cites = {};
  const text = chunks.map((c, i) => {
    const n = i + 1;
    cites[n] = { src: c.src, name: c.srcName || '', page: c.page, text: c.text };
    return '[' + n + '] (' + (c.srcName || 'source') + (c.page ? ', p.' + c.page : '') + ')\n' + c.text;
  }).join('\n\n');
  return { text, cites };
}

export const SYSTEM_CHAT = 'You are a research assistant inside a notebook app. Answer ONLY using the numbered source passages provided. ' +
  'After every claim that comes from a passage, add its number in square brackets, e.g. [2] or [1][3]. ' +
  'Never invent citations or facts. If the sources do not contain the answer, say so plainly and suggest what to add. ' +
  'Be clear and well organised; use short paragraphs or bullet points. Reply in the language of the question.';

export const STUDIO = {
  summary: { label: 'Summary', icon: '📝', kind: 'md', prompt: 'Write a clear summary of the sources: the main idea first, then key points as bullets, then a short conclusion. Cite passages with [n].' },
  briefing: { label: 'Briefing doc', icon: '📄', kind: 'md', prompt: 'Write a briefing document with these headings: Overview, Key Themes, Important Details, Open Questions. Cite passages with [n].' },
  study: { label: 'Study guide', icon: '🎓', kind: 'md', prompt: 'Create a study guide: Key Concepts (with definitions), Important Facts, Short-Answer Practice Questions (with answers), and a Glossary. Cite passages with [n].' },
  faq: { label: 'FAQ', icon: '❓', kind: 'md', prompt: 'Write 8-12 frequently asked questions a newcomer would have about these sources, each with a concise answer. Cite passages with [n].' },
  timeline: { label: 'Timeline', icon: '⏳', kind: 'md', prompt: 'Build a chronological timeline of events or developments mentioned in the sources, as a list of "date or period - what happened". If there are no dates, order the ideas logically. Cite passages with [n].' },
  mindmap: { label: 'Mind map', icon: '🧠', kind: 'json', prompt: 'Create a mind map. Return JSON: {"title": string, "children": [{"title": string, "children": [...]}]} with at most 4 levels, 4-7 branches at the top level, and short titles.' },
  flashcards: { label: 'Flashcards', icon: '🃏', kind: 'json', prompt: 'Create 12-20 flashcards covering the most important facts and concepts. Return JSON: {"cards": [{"q": string, "a": string}]}. Keep each side short.' },
  quiz: { label: 'Quiz', icon: '✅', kind: 'json', prompt: 'Create a 10-question multiple-choice quiz. Return JSON: {"questions": [{"q": string, "options": [4 strings], "answer": index 0-3, "explanation": string}]}. Mix easy and hard questions; make wrong options plausible.' },
};

export const SYSTEM_STUDIO = 'You create study material strictly from the numbered source passages provided. Do not add outside facts. ' +
  'Use clean Markdown for text outputs. When asked for JSON, return only valid JSON with no commentary.';

/** Parse JSON even if wrapped in code fences or surrounded by text. */
export function parseJSONLoose(s) {
  const t = String(s).trim();
  try { return JSON.parse(t); } catch { /* fall through */ }
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) { try { return JSON.parse(fence[1]); } catch { /* fall through */ } }
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch { /* fall through */ } }
  throw new Error('The AI did not return valid JSON. Try again.');
}

function inline(s) {
  let h = escapeHtml(s);
  h = h.replace(/`([^`]+)`/g, '<code>$1</code>');
  h = h.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
  h = h.replace(/\[(\d{1,3})\]/g, '<button class="cite" data-n="$1">$1</button>');
  return h;
}

/** Small safe Markdown renderer with citation chips. */
export function renderMarkdown(md) {
  const lines = String(md || '').replace(/\r/g, '').split('\n');
  const out = [];
  let list = null, para = [], code = null;
  const flushPara = () => { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } };
  const flushList = () => { if (list) { out.push('</' + list + '>'); list = null; } };
  for (const raw of lines) {
    if (code !== null) {
      if (raw.trim().startsWith('```')) { out.push('<pre><code>' + escapeHtml(code.join('\n')) + '</code></pre>'); code = null; }
      else code.push(raw);
      continue;
    }
    if (raw.trim().startsWith('```')) { flushPara(); flushList(); code = []; continue; }
    const line = raw.trimEnd();
    let m;
    if (!line.trim()) { flushPara(); flushList(); continue; }
    if ((m = line.match(/^(#{1,4})\s+(.*)$/))) { flushPara(); flushList(); const lv = Math.min(m[1].length + 1, 5); out.push('<h' + lv + '>' + inline(m[2]) + '</h' + lv + '>'); continue; }
    if ((m = line.match(/^\s*[-*•]\s+(.*)$/))) { flushPara(); if (list !== 'ul') { flushList(); out.push('<ul>'); list = 'ul'; } out.push('<li>' + inline(m[1]) + '</li>'); continue; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) { flushPara(); if (list !== 'ol') { flushList(); out.push('<ol>'); list = 'ol'; } out.push('<li>' + inline(m[1]) + '</li>'); continue; }
    if (/^---+$/.test(line.trim())) { flushPara(); flushList(); out.push('<hr>'); continue; }
    flushList();
    para.push(line.trim());
  }
  if (code !== null) out.push('<pre><code>' + escapeHtml(code.join('\n')) + '</code></pre>');
  flushPara(); flushList();
  return out.join('\n');
}

/** Strip HTML to readable text (for imported web pages). */
export function htmlToText(html) {
  let h = String(html);
  h = h.replace(/<(script|style|noscript|svg|nav|footer|header|form)[\s\S]*?<\/\1>/gi, ' ');
  h = h.replace(/<!--[\s\S]*?-->/g, ' ');
  h = h.replace(/<\/(p|div|h[1-6]|li|tr|section|article|br)>/gi, '\n\n').replace(/<br\s*\/?>/gi, '\n');
  h = h.replace(/<[^>]+>/g, ' ');
  h = h.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  return h.replace(/[ \t]+/g, ' ').replace(/\n\s*\n\s*\n+/g, '\n\n').trim();
}

export function titleFromHtml(html) {
  const m = String(html).match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? htmlToText(m[1]).slice(0, 80) : '';
}
