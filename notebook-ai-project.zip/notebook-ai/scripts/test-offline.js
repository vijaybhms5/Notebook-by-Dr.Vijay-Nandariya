import assert from 'node:assert/strict';
import { buildChunks } from '../www/core.js';
import { answerOffline, offlineStudio, suggestOffline, splitSentences } from '../www/offline.js';

const text = `The French Revolution began in 1789 with the storming of the Bastille. The Bastille was a fortress in Paris used as a state prison. The revolution ended the absolute monarchy and led to the First Republic in 1792.

Louis XVI was the king of France during the revolution. He was executed in 1793 after the monarchy was abolished. The Reign of Terror followed in 1793 and 1794, led by Maximilien Robespierre.

The Estates-General was an assembly representing the three estates of France: the clergy, the nobility and the commoners. The Third Estate formed the National Assembly in June 1789. Inflation and food shortages increased anger among the commoners across France.

Napoleon Bonaparte seized power in 1799. His rise ended the revolutionary period and began the Napoleonic era. The Napoleonic Code reformed French law and influenced legal systems around the world.`;
const chunks = buildChunks('s1', text).map(c => ({ ...c, srcName: 'French Revolution.txt' }));
assert.ok(chunks.length >= 1);

// sentence splitting keeps abbreviations together
assert.deepEqual(splitSentences('Dr. Smith arrived. He sat down.'), ['Dr. Smith arrived.', 'He sat down.']);
assert.equal(splitSentences('Pi is 3.14 today. Fine.').length, 2);

// chat
let r = answerOffline('When did the revolution begin?', chunks);
assert.ok(r.md.includes('1789') && /\[1\]/.test(r.md), r.md);
assert.ok(r.cites[1] && r.cites[1].text.includes('Bastille'));
r = answerOffline('What is the Estates-General?', chunks);
assert.ok(r.md.split('\n')[2].includes('assembly'), r.md);
r = answerOffline('quantum chromodynamics', chunks);
assert.ok(r.md.startsWith('I could not find'));
r = answerOffline('Give me a summary', chunks);
assert.ok(r.md.includes('## Summary'));
assert.ok(suggestOffline(chunks).length >= 3);

// studio
for (const k of ['summary', 'briefing', 'study', 'faq', 'timeline']) {
  const o = offlineStudio(k, chunks, 'French Revolution');
  assert.equal(typeof o.data, 'string'); assert.ok(o.data.length > 80, k);
  assert.ok(/\[\d+\]/.test(o.data), k + ' has citations');
  for (const n of o.data.match(/\[(\d+)\]/g).map(x => +x.slice(1, -1))) assert.ok(o.cites[n], k + ' cite ' + n);
}
const tl = offlineStudio('timeline', chunks).data;
assert.ok(tl.indexOf('1789') < tl.indexOf('1799'), 'timeline sorted');
const mm = offlineStudio('mindmap', chunks, 'French Revolution').data;
assert.equal(mm.title, 'French Revolution'); assert.ok(mm.children.length >= 3 && mm.children[0].children.length >= 1);
const fc = offlineStudio('flashcards', chunks).data.cards;
assert.ok(fc.length >= 5 && fc.every(c => c.q && c.a));
assert.ok(fc.some(c => /^What (is|are|was|were) /.test(c.q)));
const qz = offlineStudio('quiz', chunks).data.questions;
assert.ok(qz.length >= 4);
for (const q of qz) {
  assert.equal(q.options.length, 4); assert.equal(new Set(q.options).size, 4, JSON.stringify(q));
  assert.ok(q.answer >= 0 && q.answer < 4 && q.q.includes('_____'));
}
// too little text
assert.throws(() => offlineStudio('quiz', buildChunks('s2', 'Short text.').map(c => ({ ...c, srcName: 'x' }))), /not enough/);
// Hindi text works
const hi = buildChunks('s3', 'भारत एक विशाल देश है। भारत की राजधानी नई दिल्ली है। दिल्ली में संसद भवन स्थित है। भारत में कई भाषाएँ बोली जाती हैं।').map(c => ({ ...c, srcName: 'hi' }));
assert.ok(answerOffline('भारत की राजधानी', hi).md.includes('दिल्ली'));
assert.ok(!offlineStudio('study', chunks).data.includes('_____-'), 'no half-blanked hyphenated words');
assert.ok(!/^- He was executed/m.test(offlineStudio('study', chunks).data), 'pronoun-led sentences are avoided');
console.log('offline tests passed');
console.log('\n--- sample: chat ---\n' + answerOffline('Who led the Reign of Terror?', chunks).md);
console.log('\n--- sample: study guide ---\n' + offlineStudio('study', chunks).data);
console.log('\n--- sample: quiz q1 ---\n' + JSON.stringify(qz[0], null, 1));
