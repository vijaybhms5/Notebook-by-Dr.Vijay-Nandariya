// Copies the PDF and Word parsing libraries into www/lib so the APK works fully offline.
import { cpSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const lib = resolve(root, 'www/lib');
mkdirSync(lib, { recursive: true });

const files = [
  ['node_modules/pdfjs-dist/build/pdf.min.mjs', 'pdf.min.mjs'],
  ['node_modules/pdfjs-dist/build/pdf.worker.min.mjs', 'pdf.worker.min.mjs'],
  ['node_modules/mammoth/mammoth.browser.min.js', 'mammoth.browser.min.js'],
];
for (const [from, to] of files) {
  const src = resolve(root, from);
  if (!existsSync(src)) { console.error('Missing ' + from + ' - run "npm install" first'); process.exit(1); }
  cpSync(src, resolve(lib, to));
  console.log('copied', to);
}
