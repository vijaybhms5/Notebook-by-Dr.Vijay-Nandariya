import assert from 'node:assert/strict';
import { chunkText, buildChunks, searchChunks, coverageChunks, formatPassages, renderMarkdown, parseJSONLoose, htmlToText, tokenize } from '../www/core.js';

// chunking
const long = Array.from({ length: 40 }, (_, i) => 'Sentence number ' + i + ' talks about topic ' + (i % 5) + '.').join(' ');
const ch = chunkText(long, 300);
assert.ok(ch.length > 3 && ch.every(c => c.length <= 450), 'chunks are bounded');
assert.deepEqual(chunkText('   '), []);

// retrieval ranks the relevant passage first
const sourceId = 's1';
const chunks = buildChunks(sourceId, '', [
  { page: 1, text: 'The mitochondria is the powerhouse of the cell and produces ATP.' },
  { page: 2, text: 'The French Revolution began in 1789 with the storming of the Bastille.' },
  { page: 3, text: 'Photosynthesis happens in chloroplasts using sunlight.' },
]);
assert.equal(chunks.length, 3);
assert.equal(chunks[1].page, 2);
const hit = searchChunks(chunks, 'When did the French Revolution begin?', 1);
assert.equal(hit[0].page, 2);

// coverage + passages + citations
const sources = [{ id: 's1', name: 'Bio.pdf', enabled: true, chunks }, { id: 's2', name: 'Off.txt', enabled: false, chunks: [{ id: 'x', src: 's2', text: 'ignored' }] }];
const cov = coverageChunks(sources, 100000);
assert.equal(cov.length, 3);
const small = coverageChunks(sources, 120);
assert.ok(small.length < 3 && small.length >= 1);
const { text, cites } = formatPassages(cov);
assert.ok(text.includes('[1] (Bio.pdf, p.1)') && cites[2].page === 2);

// markdown
const html = renderMarkdown('# Title\n\nHello **bold** <script>x</script> [2].\n\n- a\n- b\n\n1. one\n2. two');
assert.ok(html.includes('<h2>Title</h2>') && html.includes('<strong>bold</strong>'));
assert.ok(html.includes('&lt;script&gt;') && !html.includes('<script>'));
assert.ok(html.includes('class="cite" data-n="2"'));
assert.ok(html.includes('<ul>') && html.includes('<ol>'));

// json + html
assert.deepEqual(parseJSONLoose('```json\n{"a":1}\n```'), { a: 1 });
assert.deepEqual(parseJSONLoose('Here you go: {"a":2} thanks'), { a: 2 });
assert.throws(() => parseJSONLoose('nope'));
assert.equal(htmlToText('<div>Hi&nbsp;<b>there</b><script>bad()</script></div><p>Next</p>').replace(/\s+/g, ' '), 'Hi there Next');
assert.deepEqual(tokenize('The Quick, brown fox!'), ['quick', 'brown', 'fox']);
console.log('core tests passed');
